# app/testing.py
import unittest
from app import app, db, TodoTask
from flask import json

class TodoTestCase(unittest.TestCase):
    
    def setUp(self):
        """Set up the test client and the database."""
        self.app = app.test_client()
        self.app.testing = True
        db.create_all()

    def tearDown(self):
        """Clean up after each test."""
        db.session.remove()
        db.drop_all()

    def test_create_task(self):
        """Test creating a new task."""
        response = self.app.post('/todo', json={'task': 'New task'})
        self.assertEqual(response.status_code, 201)
        self.assertIn(b'Task added', response.data)

    def test_get_tasks(self):
        """Test retrieving all tasks."""
        db.session.add(TodoTask(task='Test task'))
        db.session.commit()
        response = self.app.get('/todos')
        self.assertEqual(response.status_code, 200)
        response_json = json.loads(response.data)
        self.assertEqual(len(response_json), 1)

    def test_update_task(self):
        """Test updating a task."""
        task = TodoTask(task='Old task')
        db.session.add(task)
        db.session.commit()
        response = self.app.put(f'/todo/{task.id}', json={'task': 'Updated task', 'done': True})
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Task updated', response.data)

    def test_delete_task(self):
        """Test deleting a task."""
        task = TodoTask(task='Task to delete')
        db.session.add(task)
        db.session.commit()
        response = self.app.delete(f'/todo/{task.id}')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Task deleted', response.data)

    def test_delete_all_tasks(self):
        """Test deleting all tasks."""
        db.session.add(TodoTask(task='Task to delete'))
        db.session.commit()
        response = self.app.delete('/todos')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'All tasks deleted', response.data)

if __name__ == "__main__":
    unittest.main()

