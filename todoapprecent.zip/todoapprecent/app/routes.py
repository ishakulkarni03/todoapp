from flask import Blueprint, request, jsonify, render_template
from .models import TodoTask
from .database import db

api = Blueprint('api', __name__)

@api.route('/todo', methods=['POST'])
def create_task():
    data = request.get_json()
    new_task = TodoTask(task=data['task'])
    db.session.add(new_task)
    db.session.commit()
    return jsonify({'message': 'Task added'}), 201

@api.route('/todos', methods=['GET'])
def get_tasks():
    tasks = TodoTask.query.all()
    return jsonify([{'id': task.id, 'task': task.task, 'done': task.done} for task in tasks])

@api.route('/todo/<int:id>', methods=['PUT'])
def update_task(id):
    task = TodoTask.query.get(id)
    if not task:
        return jsonify({'message': 'Task not found'}), 404
    data = request.get_json()
    task.task = data.get('task', task.task)
    task.done = data.get('done', task.done)
    db.session.commit()
    return jsonify({'message': 'Task updated'})

@api.route('/todo/<int:id>', methods=['DELETE'])
def delete_task(id):
    task = TodoTask.query.get(id)
    if not task:
        return jsonify({'message': 'Task not found'}), 404
    db.session.delete(task)
    db.session.commit()
    return jsonify({'message': 'Task deleted'})

@api.route('/todos', methods=['DELETE'])
def delete_all_tasks():
    TodoTask.query.delete()
    db.session.commit()
    return jsonify({'message': 'All tasks deleted'})

@api.route('/')
def index():
    tasks = TodoTask.query.all()
    return render_template('index.html', tasks=tasks)
