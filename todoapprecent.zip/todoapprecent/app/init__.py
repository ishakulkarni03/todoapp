# app/__init__.py

from flask import Flask
from flask_pymongo import PyMongo

app = Flask(__name__)

# MongoDB configuration
app.config["MONGO_URI"] = "mongodb://localhost:27017/your_database_name"

# Initialize PyMongo
mongo = PyMongo(app)

@app.route('/add_task', methods=['POST'])
def add_task():
    task = {"name": "Test Task", "status": "Incomplete"}
    mongo.db.tasks.insert_one(task)
    return "Task added successfully", 201

@app.route('/tasks', methods=['GET'])
def get_tasks():
    tasks = mongo.db.tasks.find()
    tasks_list = [{"name": task["name"], "status": task["status"]} for task in tasks]
    return {"tasks": tasks_list}

if __name__ == "__main__":
    app.run(debug=True)
