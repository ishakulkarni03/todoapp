import sys
import os
import json
import pytest
from app import create_app
from app import db
from app.models import TodoTask

# Add the root directory to the system path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Fixture for testing the client
@pytest.fixture
def client():
    app = create_app()  # Create the app instance
    with app.test_client() as client:
        yield client

# Fixture to initialize the database
@pytest.fixture(scope="module")
def init_db():
    # Initialize the database and create tables
    db.create_all()
    yield db
    db.drop_all()

# Helper function to load test data from a JSON file
def load_json_data(file_path):
    with open(file_path) as f:
        return json.load(f)

# 1. Test creating a new To-Do Task using data from a JSON file
def test_create_task(client, init_db):
    data = load_json_data('test_data.json')  # Load data from the JSON file
    response = client.post('/todo', json=data)
    assert response.status_code == 201
    assert b'Task added' in response.data

# 2. Test retrieving all To-Do Tasks
def test_get_tasks(client, init_db):
    # Add a task to the database
    client.post('/todo', json={'task': 'Learn Flask'})
    response = client.get('/todos')
    assert response.status_code == 200
    assert b'Learn Flask' in response.data

# 3. Test updating a To-Do Task
def test_update_task(client, init_db):
    # Add a task first
    response = client.post('/todo', json={'task': 'Learn Flask'})
    task = TodoTask.query.first()  # Get the first task
    assert task.task == 'Learn Flask'

    # Now update the task
    response = client.put(f'/todo/{task.id}', json={'task': 'Learn Flask - Updated', 'done': True})
    assert response.status_code == 200
    assert b'Task updated' in response.data

    # Verify the task is updated in the database
    updated_task = TodoTask.query.first()
    assert updated_task.task == 'Learn Flask - Updated'
    assert updated_task.done is True

# 4. Test deleting a specific To-Do Task
def test_delete_task(client, init_db):
    # Add a task first
    response = client.post('/todo', json={'task': 'Learn Flask'})
    task = TodoTask.query.first()

    # Now delete the task
    response = client.delete(f'/todo/{task.id}')
    assert response.status_code == 200
    assert b'Task deleted' in response.data

    # Verify the task is removed from the database
    deleted_task = TodoTask.query.get(task.id)
    assert deleted_task is None

# 5. Test deleting all To-Do Tasks
def test_delete_all_tasks(client, init_db):
    # Add a couple of tasks
    client.post('/todo', json={'task': 'Learn Flask'})
    client.post('/todo', json={'task': 'Learn PostgreSQL'})

    # Now delete all tasks
    response = client.delete('/todos')
    assert response.status_code == 200
    assert b'All tasks deleted' in response.data

    # Verify no tasks remain in the database
    remaining_tasks = TodoTask.query.all()
    assert len(remaining_tasks) == 0
